/**
 * File System Utilities
 *
 * - Gitignore-aware directory walker
 * - Meteor method string-to-file resolver
 * - tsconfig alias resolver
 * - Blast-radius dependency tracer (static import graph)
 */

import { readFile, readdir, stat } from 'fs/promises';
import { existsSync } from 'fs';
import { resolve, join, relative, extname, dirname, basename } from 'path';

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------
const ALWAYS_IGNORE = new Set([
  'node_modules', '.git', '.next', 'dist', 'build', '.turbo',
  'coverage', '.cache', '__pycache__', '.DS_Store', '*.min.js',
]);

const CODE_EXTENSIONS = new Set([
  '.ts', '.tsx', '.js', '.jsx', '.mjs', '.cjs',
]);

// ---------------------------------------------------------------------------
// Directory walker (gitignore-aware, returns relative paths)
// ---------------------------------------------------------------------------
export async function walkDirectory(rootDir, options = {}) {
  const {
    maxFiles = 5000,
    extensions = CODE_EXTENSIONS,
    respectGitignore = true,
  } = options;

  const absRoot = resolve(rootDir);
  const files = [];
  const gitignorePatterns = respectGitignore
    ? await loadGitignorePatterns(absRoot)
    : [];

  async function walk(dir) {
    if (files.length >= maxFiles) return;

    let entries;
    try {
      entries = await readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }

    for (const entry of entries) {
      if (files.length >= maxFiles) return;

      const fullPath = join(dir, entry.name);
      const relPath = relative(absRoot, fullPath);

      if (shouldIgnore(entry.name, relPath, gitignorePatterns)) continue;

      if (entry.isDirectory()) {
        await walk(fullPath);
      } else if (entry.isFile()) {
        const ext = extname(entry.name).toLowerCase();
        if (extensions.has(ext)) {
          files.push(relPath);
        }
      }
    }
  }

  await walk(absRoot);
  return files;
}

function shouldIgnore(name, relPath, patterns) {
  // Always-ignore list
  for (const ig of ALWAYS_IGNORE) {
    if (ig.startsWith('*')) {
      if (name.endsWith(ig.slice(1))) return true;
    } else {
      if (name === ig) return true;
    }
  }

  // Gitignore patterns (simple prefix/suffix matching)
  for (const pattern of patterns) {
    if (relPath.startsWith(pattern) || name === pattern) return true;
    if (pattern.startsWith('*') && name.endsWith(pattern.slice(1))) return true;
  }

  return false;
}

async function loadGitignorePatterns(rootDir) {
  const gitignorePath = join(rootDir, '.gitignore');
  if (!existsSync(gitignorePath)) return [];

  try {
    const content = await readFile(gitignorePath, 'utf-8');
    return content
      .split('\n')
      .map(l => l.trim())
      .filter(l => l && !l.startsWith('#'))
      .map(l => l.replace(/^\//, '').replace(/\/$/, ''));
  } catch {
    return [];
  }
}

// ---------------------------------------------------------------------------
// Meteor method resolver
// Scans apps/meteor/server/methods/ and maps method name → file path
// ---------------------------------------------------------------------------
export async function buildMeteorMethodMap(repoRoot) {
  const methodsDir = join(repoRoot, 'apps', 'meteor', 'server', 'methods');
  const map = {}; // methodName → relativeFilePath

  if (!existsSync(methodsDir)) {
    return map; // Not a Rocket.Chat repo or non-standard layout
  }

  const files = await walkDirectory(methodsDir, { maxFiles: 500 });

  for (const relFile of files) {
    // Convention: file name often matches method name
    const name = basename(relFile, extname(relFile));
    const absFile = join(methodsDir, relFile);
    map[name] = relative(repoRoot, absFile);

    // Also scan for Meteor.methods() calls to extract string keys
    try {
      const src = await readFile(absFile, 'utf-8');
      const matches = src.matchAll(/Meteor\.methods\s*\(\s*\{([^}]*)\}/gs);
      for (const match of matches) {
        const block = match[1];
        const keyMatches = block.matchAll(/['"]([^'"]+)['"]\s*:/g);
        for (const km of keyMatches) {
          map[km[1]] = relative(repoRoot, absFile);
        }
      }
    } catch {
      // skip unreadable files
    }
  }

  return map;
}

// ---------------------------------------------------------------------------
// tsconfig alias resolver
// Parses tsconfig.json / tsconfig.base.json path aliases
// ---------------------------------------------------------------------------
export async function buildAliasMap(repoRoot) {
  const candidates = [
    'tsconfig.json',
    'tsconfig.base.json',
    'apps/meteor/tsconfig.json',
  ];

  const aliasMap = {}; // @alias → resolved directory

  for (const candidate of candidates) {
    const tsconfigPath = join(repoRoot, candidate);
    if (!existsSync(tsconfigPath)) continue;

    try {
      const raw = await readFile(tsconfigPath, 'utf-8');
      // Strip comments (tsconfig allows // comments)
      const stripped = raw.replace(/\/\/[^\n]*/g, '').replace(/\/\*[\s\S]*?\*\//g, '');
      const tsconfig = JSON.parse(stripped);
      const paths = tsconfig?.compilerOptions?.paths ?? {};
      const baseUrl = tsconfig?.compilerOptions?.baseUrl ?? '.';
      const baseDir = resolve(dirname(tsconfigPath), baseUrl);

      for (const [alias, targets] of Object.entries(paths)) {
        if (!Array.isArray(targets) || targets.length === 0) continue;
        const firstTarget = targets[0].replace(/\/\*$/, '');
        const resolved = relative(repoRoot, resolve(baseDir, firstTarget));
        const cleanAlias = alias.replace(/\/\*$/, '');
        aliasMap[cleanAlias] = resolved;
      }
    } catch {
      // skip malformed tsconfig
    }
  }

  return aliasMap;
}

// ---------------------------------------------------------------------------
// Static import graph builder
// Parses import statements to build a simple adjacency list
// Used for blast-radius analysis
// ---------------------------------------------------------------------------
export async function buildImportGraph(repoRoot, files) {
  const graph = {}; // file → Set<importedFile>
  const reverseGraph = {}; // file → Set<importerFile>

  for (const file of files) {
    graph[file] = new Set();
    reverseGraph[file] = new Set();
  }

  const fileSet = new Set(files);

  for (const file of files) {
    const absPath = join(repoRoot, file);
    let src;
    try {
      src = await readFile(absPath, 'utf-8');
    } catch {
      continue;
    }

    // Extract static imports
    const importMatches = src.matchAll(/^import\s+.*?from\s+['"]([^'"]+)['"]/gm);
    for (const match of importMatches) {
      const importPath = match[1];
      if (importPath.startsWith('.')) {
        // Relative import — resolve
        const resolved = resolveRelativeImport(file, importPath, fileSet);
        if (resolved) {
          graph[file].add(resolved);
          if (!reverseGraph[resolved]) reverseGraph[resolved] = new Set();
          reverseGraph[resolved].add(file);
        }
      }
    }
  }

  return { graph, reverseGraph };
}

function resolveRelativeImport(fromFile, importPath, fileSet) {
  const fromDir = dirname(fromFile);
  const base = join(fromDir, importPath);

  const candidates = [
    base,
    `${base}.ts`,
    `${base}.tsx`,
    `${base}.js`,
    `${base}/index.ts`,
    `${base}/index.js`,
  ];

  for (const candidate of candidates) {
    // Normalize path separators
    const normalized = candidate.replace(/\\/g, '/');
    if (fileSet.has(normalized)) return normalized;
  }

  return null;
}

// ---------------------------------------------------------------------------
// Blast-radius tracer
// Returns the transitive set of files that import a given file
// ---------------------------------------------------------------------------
export function computeBlastRadius(targetFile, reverseGraph, maxDepth = 4) {
  const affected = new Set();
  const queue = [{ file: targetFile, depth: 0 }];

  while (queue.length > 0) {
    const { file, depth } = queue.shift();
    if (depth > maxDepth) continue;

    const importers = reverseGraph[file] ?? new Set();
    for (const importer of importers) {
      if (!affected.has(importer)) {
        affected.add(importer);
        queue.push({ file: importer, depth: depth + 1 });
      }
    }
  }

  return Array.from(affected);
}

// ---------------------------------------------------------------------------
// Module tree builder (high-level directory overview for JIT Level 1)
// ---------------------------------------------------------------------------
export async function buildModuleTree(repoRoot, maxDepth = 3) {
  const absRoot = resolve(repoRoot);
  const tree = {};

  async function walk(dir, node, depth) {
    if (depth > maxDepth) return;

    let entries;
    try {
      entries = await readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }

    for (const entry of entries) {
      if (shouldIgnore(entry.name, entry.name, [])) continue;

      if (entry.isDirectory()) {
        node[entry.name + '/'] = {};
        await walk(join(dir, entry.name), node[entry.name + '/'], depth + 1);
      } else {
        const ext = extname(entry.name).toLowerCase();
        if (CODE_EXTENSIONS.has(ext)) {
          node[entry.name] = null;
        }
      }
    }
  }

  await walk(absRoot, tree, 0);
  return tree;
}

// ---------------------------------------------------------------------------
// Format module tree as a readable string
// ---------------------------------------------------------------------------
export function formatModuleTree(tree, prefix = '', maxLines = 200) {
  const lines = [];

  function render(node, pfx) {
    if (lines.length >= maxLines) return;
    for (const [key, value] of Object.entries(node)) {
      if (lines.length >= maxLines) return;
      if (value === null) {
        lines.push(`${pfx}${key}`);
      } else {
        lines.push(`${pfx}${key}`);
        render(value, pfx + '  ');
      }
    }
  }

  render(tree, prefix);
  return lines.join('\n');
}
