/**
 * JIT Hydration State Manager
 *
 * Manages the agent's progressive disclosure phase:
 *   Level 1 — Discovery:  list_files → 2k tokens
 *   Level 2 — Navigation: read_file_skeleton → 10k tokens
 *   Level 3 — Action:     read_symbol_details → 500 tokens per symbol
 *
 * State is kept in memory for the session. The agent advances phases
 * by calling the appropriate tools in order.
 */

// Phase constants
export const PHASE = {
  DISCOVERY: 1,
  NAVIGATION: 2,
  ACTION: 3,
};

class JITState {
  constructor() {
    this.phase = PHASE.DISCOVERY;
    this.exploredFiles = new Set();
    this.skeletonizedFiles = new Set();
    this.hydratedSymbols = new Map(); // symbol → { file, content }
    this.meteorMethodMap = null;
    this.aliasMap = null;
    this.importGraph = null;
    this.fileList = null;
    this.moduleTree = null;
  }

  advanceTo(phase) {
    if (phase > this.phase) {
      this.phase = phase;
    }
  }

  markExplored(filePath) {
    this.exploredFiles.add(filePath);
    this.advanceTo(PHASE.NAVIGATION);
  }

  markSkeletonized(filePath) {
    this.skeletonizedFiles.add(filePath);
    this.advanceTo(PHASE.ACTION);
  }

  cacheSymbol(symbolName, file, content) {
    this.hydratedSymbols.set(symbolName, { file, content, ts: Date.now() });
  }

  getSymbol(symbolName) {
    return this.hydratedSymbols.get(symbolName) ?? null;
  }

  summary() {
    return {
      phase: this.phase,
      phaseName: Object.keys(PHASE)[this.phase - 1],
      exploredFiles: this.exploredFiles.size,
      skeletonizedFiles: this.skeletonizedFiles.size,
      hydratedSymbols: this.hydratedSymbols.size,
    };
  }
}

// Singleton per process
export const jitState = new JITState();
